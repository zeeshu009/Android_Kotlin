package com.mistercoding.recyclerview

class DataItemType {

    companion object{
        const val BEST_SELLER = 0;
        const val CLOTHING = 1;
        const val BANNER = 2
    }
}