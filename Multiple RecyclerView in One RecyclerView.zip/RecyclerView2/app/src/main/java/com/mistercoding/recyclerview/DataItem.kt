package com.mistercoding.recyclerview

data class DataItem(
    val viewType:Int
){
    var recyclerItemList : List<RecyclerItem>? = null
    var banner : Banner ? = null

    //overloading constructor for recyclerItemList and banner i.e secondory constructor
    constructor(viewType: Int,recyclerItem:List<RecyclerItem>):this(viewType)
    {
        this.recyclerItemList = recyclerItem
    }
    constructor(viewType: Int,banner: Banner):this(viewType){
        this.banner = banner
    }
}

data class RecyclerItem(val image:Int,val offer:String)
data class Banner(val image: Int)


