package com.mistercoding.recyclerview

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.mistercoding.recyclerview.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {
    private lateinit var binding : ActivityMainBinding
    private lateinit var mList: ArrayList<DataItem>
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.mainRecylerView.setHasFixedSize(true)
        binding.mainRecylerView.layoutManager = LinearLayoutManager(this)
        // initilize ArrayList in Kotlin
        mList = ArrayList()

        AddDataToList()

        val adapter = MainAdapter(mList)
        binding.mainRecylerView.adapter = adapter

    }

    private fun AddDataToList() {

        // creating a best seller list

        val bestSellerlist = ArrayList<RecyclerItem>()

        bestSellerlist.add(RecyclerItem(R.drawable.cat_1,"Upto 20% off"))
        bestSellerlist.add(RecyclerItem(R.drawable.cat_2,"Upto 10% off"))
        bestSellerlist.add(RecyclerItem(R.drawable.cat_3,"Upto 30% off"))
        bestSellerlist.add(RecyclerItem(R.drawable.cat_4,"Upto 40% off"))


        // creating clothingList

        val clothingList = ArrayList<RecyclerItem>()

        clothingList.add(RecyclerItem(R.drawable.cat_1,"Upto 20% off"))
        clothingList.add(RecyclerItem(R.drawable.cat_2,"Upto 10% off"))
        clothingList.add(RecyclerItem(R.drawable.cat_3,"Upto 30% off"))
        clothingList.add(RecyclerItem(R.drawable.cat_4,"Upto 40% off"))

        mList.add(DataItem(DataItemType.BEST_SELLER,bestSellerlist))
        mList.add(DataItem(DataItemType.BANNER, Banner(R.drawable.cat_5)))
        mList.add(DataItem(DataItemType.CLOTHING,clothingList))
        mList.add(DataItem(DataItemType.BEST_SELLER,bestSellerlist.asReversed()))
        mList.add(DataItem(DataItemType.BANNER, Banner(R.drawable.cat_5)))
        mList.add(DataItem(DataItemType.CLOTHING,clothingList))



    }
}