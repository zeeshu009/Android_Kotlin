package com.mistercoding.recyclerview

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.constraintlayout.widget.ConstraintLayout
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.mistercoding.recyclerview.databinding.ItemWithPosterBinding
import com.mistercoding.recyclerview.databinding.ItemWithoutPosterBinding

// const for 2 layouts if you have more then used more constant
const val itemWithPoster = 0;
const val itemWithOutPoster = 1;

class MainAdapter(private val mList : List<DataItem>)
    :RecyclerView.Adapter<RecyclerView.ViewHolder>(){

        // this class is used for itemPost layout
    inner class ItemWithPoster(val binding: ItemWithPosterBinding):RecyclerView.ViewHolder(binding.root)
    {
       fun bindPosterView(dataItem: DataItem){
           dataItem.poster?.let { binding.posterIv.setImageResource(it) }
           binding.movieTitleTv.text = dataItem.title
           binding.movieDescTv.text = dataItem.desc
       }
    }
    // this class is used for itemWithoutPoster
    inner class ItemWithOutPoster(val binding: ItemWithoutPosterBinding):RecyclerView.ViewHolder(binding.root){
        fun bindWithOutPosterView(dataItem: DataItem)
        {
            binding.movieTitleTv.text = dataItem.title
            dataItem.logo?.let { binding.logoIv.setImageResource(dataItem.logo) }
        }
    }
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {

        if (viewType== itemWithPoster)
        {
            val binding = ItemWithPosterBinding.inflate(LayoutInflater.from(parent.context),parent,false)
            return ItemWithPoster(binding)
        }
        else
        {
            val binding = ItemWithoutPosterBinding.inflate(LayoutInflater.from(parent.context),parent,false)
            return ItemWithOutPoster(binding)
        }
    }

    override fun getItemCount(): Int {
        return mList.size
    }
    // this will gave us itemViewType
    override fun getItemViewType(position: Int): Int {

        if(mList[position].poster!=null)
            return itemWithPoster
        else
            return itemWithOutPoster

    }

    override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {

        if(getItemViewType(position)== itemWithPoster)
        {
            //type casting
            (holder as ItemWithPoster).bindPosterView(mList[position])
        }
        else
        {
            (holder as ItemWithOutPoster).bindWithOutPosterView(mList[position])
        }
    }


}