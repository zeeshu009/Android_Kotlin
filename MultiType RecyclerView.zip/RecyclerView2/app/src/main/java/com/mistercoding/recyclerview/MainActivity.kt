package com.mistercoding.recyclerview

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.mistercoding.recyclerview.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {
    private lateinit var binding : ActivityMainBinding
    private lateinit var mList: ArrayList<DataItem>
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.RecylerView.setHasFixedSize(true)
        binding.RecylerView.layoutManager = LinearLayoutManager(this)
        // initilize ArrayList in Kotlin
        mList = ArrayList()

        AddDataToList()

        val adapter = MainAdapter(mList)
        binding.RecylerView.adapter = adapter

    }

    private fun AddDataToList() {
        mList.add(DataItem("Cat 2","This is Cat 2",null,R.drawable.cat_2))
        mList.add(DataItem("Cat 4","This is Cat 4",R.drawable.cat_4,R.drawable.cat_4))
        mList.add(DataItem("Cat 3","This is Cat 3",null,R.drawable.cat_3))
        mList.add(DataItem("Cat 1","This is Cat ",R.drawable.cat_1,R.drawable.cat_1))

    }
}