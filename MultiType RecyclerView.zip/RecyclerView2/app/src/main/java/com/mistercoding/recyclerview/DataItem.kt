package com.mistercoding.recyclerview

data class DataItem(
    val title : String,
    val desc : String?,
    val poster : Int?,
    val logo : Int?
)


