package com.mistercoding.recyclerview

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class FoodAdapter(private val FoodList: ArrayList<Food>) :
    RecyclerView.Adapter<FoodAdapter.FoodViewHolder>() {

    // in this class we have to find all widget id from layout which we select
    // for recycler view
    class FoodViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val foodImage: ImageView = itemView.findViewById(R.id.imageView)
        val foodName: TextView = itemView.findViewById(R.id.textView)
    }


    // in this method we have to return layout view like item layout in our project
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): FoodViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item,parent,false)
        return FoodViewHolder(view)
    }

    override fun getItemCount(): Int {
        return FoodList.size
    }

    // we have to set data of every item in this class
    override fun onBindViewHolder(holder: FoodViewHolder, position: Int) {

        val food = FoodList[position]
        // with the help of holder we have to set each item like image and text in this
        // project

        holder.foodImage.setImageResource(food.image)
        holder.foodName.text = food.name


    }
}