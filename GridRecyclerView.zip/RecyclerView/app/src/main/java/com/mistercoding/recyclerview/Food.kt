package com.mistercoding.recyclerview

import android.os.Parcel
import android.os.Parcelable

//Data class for storing image and food name in card view i.e item layout
// image consider as Int in drawable resource

data class Food(val image:Int,val name:String)
