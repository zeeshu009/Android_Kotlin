package com.mistercoding.recyclerview

data class DataItem(
    val itemText : String
)
