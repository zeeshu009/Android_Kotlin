package com.mistercoding.recyclerview

import android.annotation.SuppressLint
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.constraintlayout.widget.ConstraintLayout
import androidx.recyclerview.widget.RecyclerView

class CatAdapter (var catList: ArrayList<Cat>):RecyclerView.Adapter<CatAdapter.catViewHolder>()
{
    class catViewHolder(itemView: View) :RecyclerView.ViewHolder(itemView){
        val image :ImageView = itemView.findViewById(R.id.itemImageView)
        val name : TextView = itemView.findViewById(R.id.itemTextView)
        val des :TextView = itemView.findViewById(R.id.description)
        val constraintLayout : ConstraintLayout = itemView.findViewById(R.id.constraintLayout)

        fun collapseExpandableView(){
           des.visibility = View.GONE
        }


    }

    @SuppressLint("NotifyDataSetChanged")
    fun setFilterList(list:ArrayList<Cat>){
        this.catList = list
        notifyDataSetChanged()
    }
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): catViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item,parent,false)
        return catViewHolder(view)

    }

    override fun getItemCount(): Int {
        return catList.size
    }

    override fun onBindViewHolder(holder: catViewHolder, position: Int) {
        holder.image.setImageResource(catList[position].image)
        holder.name.text = catList[position].name
        holder.des.text = catList[position].des

        val isExpandable : Boolean = catList[position].isExpandable

        holder.des.visibility = if(isExpandable) View.VISIBLE else View.GONE

        holder.constraintLayout.setOnClickListener {
            isAnyItemExpandable(position)
            catList[position].isExpandable = !catList[position].isExpandable
            notifyItemChanged(position,Unit)
        }

    }

    override fun onBindViewHolder(
        holder: catViewHolder,
        position: Int,
        payloads: MutableList<Any>
    ) {
        //if my payload is zero then we will collapse the view of description
        // if payload[0] == 0 mean we compare to 0 which we passed from isAnyItemExpandable
        if(payloads.isNotEmpty() && payloads[0]==0)
        {
              holder.collapseExpandableView()
        }
        else
        {
            super.onBindViewHolder(holder, position, payloads)
        }

    }
    private fun isAnyItemExpandable(position: Int) {
        // this will iterate the whole catList and return index if any item
        // is expandable
        val temp = catList.indexOfFirst {
            it.isExpandable
        }
        if(temp>=0 && temp!=position)
        {
            catList[temp].isExpandable = false
            // this will call onViewBindHolder function that have parameter payload i.e 2nd function
            // pass 0 as payload i.e constant value
            notifyItemChanged(temp,0)
        }

    }
}