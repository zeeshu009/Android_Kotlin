package com.mistercoding.recyclerview

//Data class for storing image and food name in card view i.e item layout
// image consider as Int in drawable resource

data class Cat(val image:Int, val name:String, val des:String, var isExpandable:Boolean=false)

