package com.mistercoding.recyclerview

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.SearchView
import android.widget.Toast
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import java.util.Locale

class MainActivity : AppCompatActivity() {

    private lateinit var recyclerView: RecyclerView
    private lateinit var searchView: SearchView
    private lateinit var catList : ArrayList<Cat>
    private lateinit var catAdapter: CatAdapter
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        recyclerView = findViewById(R.id.recylerView)
        searchView = findViewById(R.id.searchView)

        recyclerView.setHasFixedSize(true)
        recyclerView.layoutManager = LinearLayoutManager(this)
        catList = ArrayList()
        addDataToList()

        catAdapter = CatAdapter(catList)
        recyclerView.adapter = catAdapter

        searchView.setOnQueryTextListener(object :SearchView.OnQueryTextListener{
            override fun onQueryTextSubmit(query: String?): Boolean {
                return false
            }

            override fun onQueryTextChange(newText: String?): Boolean {
              filterList(newText)
              return true
            }

        })

    }

    private fun filterList(query:String?){
        if(query!=null)
        {
            val filterlist = ArrayList<Cat>()
            for (food in catList){
                if(food.name.lowercase(Locale.ROOT).contains(query))
                {
                    filterlist.add(food)
                }
            }
            if(filterlist.isEmpty())
                Toast.makeText(this,"No data Found ",Toast.LENGTH_LONG).show()
            else
            {
                catAdapter.setFilterList(filterlist)
            }

        }
    }

    private fun addDataToList()
    {
        catList.add(Cat(R.drawable.cat_1,"cat_1","this is cat you know :("))
        catList.add(Cat(R.drawable.cat_2,"cat_2","this is cat you know :("))
        catList.add(Cat(R.drawable.cat_4,"cat_4","this is cat you know :("))
        catList.add(Cat(R.drawable.cat_1,"cat_1","this is cat you know :("))
        catList.add(Cat(R.drawable.cat_2,"cat_2","this is cat you know :("))
        catList.add(Cat(R.drawable.cat_4,"cat_4","this is cat you know :("))
        catList.add(Cat(R.drawable.cat_5,"cat_5","this is cat you know :("))
        catList.add(Cat(R.drawable.cat_6,"cat_6","this is cat you know :("))
        catList.add(Cat(R.drawable.cat_1,"cat_1","this is cat you know :("))
        catList.add(Cat(R.drawable.cat_2,"cat_2","this is cat you know :("))
        catList.add(Cat(R.drawable.cat_5,"cat_5","this is cat you know :("))
        catList.add(Cat(R.drawable.cat_6,"Meow","this is cat you know :("))
        catList.add(Cat(R.drawable.cat_5,"cat_5","this is cat you know :("))
        catList.add(Cat(R.drawable.cat_6,"cat_6","this is cat you know :("))
        catList.add(Cat(R.drawable.cat_1,"cat_1","this is cat you know :("))
        catList.add(Cat(R.drawable.cat_2,"cat_2","this is cat you know :("))
        catList.add(Cat(R.drawable.cat_5,"cat_5","this is cat you know :("))
        catList.add(Cat(R.drawable.cat_6,"cat_6","this is cat you know :("))
    }
}