package com.mistercoding.recyclerview

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.ImageView
import android.widget.TextView

class DetailsActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_details)

        val food = intent.getParcelableExtra<Food>("food")

        if(food!=null)
        {
            val name : TextView = findViewById(R.id.detailsText)
            val foodImg : ImageView = findViewById(R.id.detailsImg)

            name.text = food.name
            foodImg.setImageResource(food.image)
        }
    }
}