package com.mistercoding.recyclerview

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class FoodAdapter(private val foodList:ArrayList<Food>)
    :RecyclerView.Adapter<FoodAdapter.FoodViewHolder>(){

    class FoodViewHolder(itemView: View):RecyclerView.ViewHolder(itemView){
        //now in this class find id of Image and food Name from item layout
        val img : ImageView = itemView.findViewById(R.id.imageView)
        val name :TextView = itemView.findViewById(R.id.textView)



    }

    var onItemClick : ((Food)->Unit)?=null

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): FoodViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item,parent,false)
        return FoodViewHolder(view)
    }

    override fun getItemCount(): Int {
        return foodList.size
    }

    override fun onBindViewHolder(holder: FoodViewHolder, position: Int) {
        val food = foodList[position]
        holder.img.setImageResource(food.image)
        holder.name.text = food.name

        holder.itemView.setOnClickListener {
            onItemClick?.invoke(food)
        }
    }
}