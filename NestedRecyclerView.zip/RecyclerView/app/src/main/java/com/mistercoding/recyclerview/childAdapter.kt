package com.mistercoding.recyclerview

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class childAdapter(private val childList: List<childItem>):RecyclerView.Adapter<childAdapter.childViewHolder>() {

    inner class childViewHolder(itemView: View):RecyclerView.ViewHolder(itemView){
     val img : ImageView = itemView.findViewById(R.id.chidlImageView)
     val txt : TextView = itemView.findViewById(R.id.childTextView)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): childViewHolder {
       val view = LayoutInflater.from(parent.context).inflate(R.layout.item,parent,false)
        return childViewHolder(view)
    }

    override fun getItemCount(): Int {
        return childList.size
    }

    override fun onBindViewHolder(holder: childViewHolder, position: Int) {
        val childItem = childList[position]
        holder.img.setImageResource(childItem.img)
        holder.txt.text = childItem.title
    }
}