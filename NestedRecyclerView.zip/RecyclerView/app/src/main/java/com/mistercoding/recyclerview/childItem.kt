package com.mistercoding.recyclerview

data class childItem(val title:String,val img:Int)
