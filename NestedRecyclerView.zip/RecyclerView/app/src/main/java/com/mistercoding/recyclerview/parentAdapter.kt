package com.mistercoding.recyclerview

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView

class parentAdapter(private val parentList: List<parentItem>):RecyclerView.Adapter<parentAdapter.parentViewHolder>() {

    inner class parentViewHolder(itemView:View):RecyclerView.ViewHolder(itemView)
    {
        val img : ImageView = itemView.findViewById(R.id.parentIamgeView)
        val txt : TextView = itemView.findViewById(R.id.parentTextView)
        val childRecyclerView : RecyclerView = itemView.findViewById(R.id.childRecyclerView)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): parentViewHolder {
        val  view = LayoutInflater.from(parent.context).inflate(R.layout.parent_layout,parent,false)
        return  parentViewHolder(view)
    }

    override fun getItemCount(): Int {
        return parentList.size
    }

    override fun onBindViewHolder(holder: parentViewHolder, position: Int) {
       val parentItem = parentList[position]

        holder.img.setImageResource(parentItem.img)
        holder.txt.text = parentItem.title

        holder.childRecyclerView.setHasFixedSize(true)
        holder.childRecyclerView.layoutManager = GridLayoutManager(holder.itemView.context,3)

        val adapter = childAdapter(parentItem.list)
        holder.childRecyclerView.adapter = adapter
    }
}