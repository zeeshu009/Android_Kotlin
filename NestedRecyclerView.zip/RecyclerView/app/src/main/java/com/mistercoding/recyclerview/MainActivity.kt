package com.mistercoding.recyclerview

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.SearchView
import android.widget.Toast
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import java.util.Locale

class MainActivity : AppCompatActivity() {

    private  lateinit var recyclerView: RecyclerView
    private val parentList = ArrayList<parentItem>()
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        recyclerView = findViewById(R.id.parentRecyclerView)
        recyclerView.setHasFixedSize(true)
        recyclerView.layoutManager = LinearLayoutManager(this)


       AddDataToList()

        val adapter = parentAdapter(parentList)
        recyclerView.adapter = adapter


    }

    private fun AddDataToList() {
        val childItem = ArrayList<childItem>()
        childItem.add(childItem("cat_1",R.drawable.cat_1))


        parentList.add(parentItem("cat_1",R.drawable.cat_1,childItem))

        val childItem2 = ArrayList<childItem>()
        childItem2.add(childItem("cat_1",R.drawable.cat_1))
        childItem2.add(childItem("cat_2",R.drawable.cat_2))


        parentList.add(parentItem("cat_2",R.drawable.cat_2,childItem2))

        val childItem3 = ArrayList<childItem>()
        childItem3.add(childItem("cat_1",R.drawable.cat_1))
        childItem3.add(childItem("cat_2",R.drawable.cat_2))
        childItem3.add(childItem("cat_3",R.drawable.cat_3))


        parentList.add(parentItem("cat_3",R.drawable.cat_3,childItem3))

        val childItem4 = ArrayList<childItem>()
        childItem4.add(childItem("cat_1",R.drawable.cat_1))
        childItem4.add(childItem("cat_2",R.drawable.cat_2))
        childItem4.add(childItem("cat_3",R.drawable.cat_3))
        childItem4.add(childItem("cat_4",R.drawable.cat_4))


        parentList.add(parentItem("cat_3",R.drawable.cat_4,childItem4))
    }
}


