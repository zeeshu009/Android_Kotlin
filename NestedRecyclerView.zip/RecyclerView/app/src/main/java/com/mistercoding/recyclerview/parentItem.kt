package com.mistercoding.recyclerview

data class parentItem(val title:String,val img:Int,val list: List<childItem>)
