package com.mistercoding.recyclerview

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.LinearSnapHelper
import androidx.recyclerview.widget.RecyclerView
import androidx.recyclerview.widget.SnapHelper

class MainActivity : AppCompatActivity() {

    private lateinit var recyclerView: RecyclerView
    private lateinit var foodList:ArrayList<Food>
    private lateinit var foodAdapter: FoodAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        init()

    }
    private fun init()
    {
        recyclerView = findViewById(R.id.recyclerView)
        recyclerView.setHasFixedSize(true)
        // how to manage recycler view we used layout manager
        recyclerView.layoutManager = LinearLayoutManager(this,RecyclerView.HORIZONTAL,false)
        // for smoothness we used snapHelper
        val snapHelper : SnapHelper = LinearSnapHelper()
        snapHelper.attachToRecyclerView(recyclerView)

        foodList = ArrayList()
        addDataToList()

        // now initialize our FoodAdapter class and passing foodlist in it
        foodAdapter = FoodAdapter(foodList)
        recyclerView.adapter = foodAdapter
    }

    private fun addDataToList()
    {
        foodList.add(Food(R.drawable.pic1,"soy"))
        foodList.add(Food(R.drawable.pic2,"pizza"))
        foodList.add(Food(R.drawable.pic3,"pasta"))
        foodList.add(Food(R.drawable.pic1,"soy"))
        foodList.add(Food(R.drawable.pic2,"pizza"))
        foodList.add(Food(R.drawable.pic3,"pasta"))
        foodList.add(Food(R.drawable.pic1,"soy"))
        foodList.add(Food(R.drawable.pic2,"pizza"))
        foodList.add(Food(R.drawable.pic3,"pasta"))
    }
}