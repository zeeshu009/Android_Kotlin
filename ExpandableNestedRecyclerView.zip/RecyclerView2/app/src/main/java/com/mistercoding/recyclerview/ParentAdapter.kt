package com.mistercoding.recyclerview

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.constraintlayout.widget.ConstraintLayout
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView

class ParentAdapter(private val ParenList : List<ParentItem>)
    :RecyclerView.Adapter<ParentAdapter.ParentRecyclerViewHolder>(){

    inner class ParentRecyclerViewHolder(itemView: View): RecyclerView.ViewHolder(itemView)
    {
        val parentTitle : TextView = itemView.findViewById(R.id.parentTextView)
        val parentImg : ImageView = itemView.findViewById(R.id.parentIamgeView)
        val childRecyclerView : RecyclerView = itemView.findViewById(R.id.childRecyclerView)
        val constraintlayout : ConstraintLayout = itemView.findViewById(R.id.constrainLayout)

    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ParentRecyclerViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.parent_layout,parent,false)
        return  ParentRecyclerViewHolder(view)
    }

    override fun getItemCount(): Int {
        return ParenList.size
    }

    override fun onBindViewHolder(holder: ParentRecyclerViewHolder, position: Int) {
        val parentItem = ParenList[position]

        holder.parentTitle.text = parentItem.title
        holder.parentImg.setImageResource(parentItem.img)
        holder.childRecyclerView.setHasFixedSize(true)

        holder.childRecyclerView.layoutManager = GridLayoutManager(holder.itemView.context,3)

        val adapter = ChildAdapter(parentItem.ChildItemList)
        holder.childRecyclerView.adapter = adapter

        //Expandable Functionality

        val isExpandable = parentItem.isExpandable
        holder.childRecyclerView.visibility = if(isExpandable) View.VISIBLE else View.GONE

        holder.constraintlayout.setOnClickListener {
            isAnyItemExpanded(position)
            parentItem.isExpandable = !parentItem.isExpandable
            notifyItemChanged(position)
        }


    }

    private fun isAnyItemExpanded(position: Int) {
        val temp = ParenList.indexOfFirst {
            it.isExpandable
        }
        if(temp>=0 && temp!=position)
        {
            ParenList[temp].isExpandable = false
            notifyItemChanged(temp)
        }

    }
}