package com.mistercoding.recyclerview

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

class MainActivity : AppCompatActivity() {
    private lateinit var parentRecyclerView: RecyclerView
    private val parentList = ArrayList<ParentItem>()
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        parentRecyclerView = findViewById(R.id.ParentRecylerView)
        parentRecyclerView.setHasFixedSize(true)
        parentRecyclerView.layoutManager = LinearLayoutManager(this)

        AddDataToList()

        val adapter = ParentAdapter(parentList)
        parentRecyclerView.adapter = adapter

    }

    private fun AddDataToList() {
        val childItem = ArrayList<ChildItem>()
        childItem.add(ChildItem("cat_1",R.drawable.cat_1))


        parentList.add(ParentItem("cat_1",R.drawable.cat_1,childItem))

        val childItem2 = ArrayList<ChildItem>()
        childItem2.add(ChildItem("cat_1",R.drawable.cat_1))
        childItem2.add(ChildItem("cat_2",R.drawable.cat_2))


        parentList.add(ParentItem("cat_2",R.drawable.cat_2,childItem2))

        val childItem3 = ArrayList<ChildItem>()
        childItem3.add(ChildItem("cat_1",R.drawable.cat_1))
        childItem3.add(ChildItem("cat_2",R.drawable.cat_2))
        childItem3.add(ChildItem("cat_3",R.drawable.cat_3))


        parentList.add(ParentItem("cat_3",R.drawable.cat_3,childItem3))

        val childItem4 = ArrayList<ChildItem>()
        childItem4.add(ChildItem("cat_1",R.drawable.cat_1))
        childItem4.add(ChildItem("cat_2",R.drawable.cat_2))
        childItem4.add(ChildItem("cat_3",R.drawable.cat_3))
        childItem4.add(ChildItem("cat_4",R.drawable.cat_4))


        parentList.add(ParentItem("cat_3",R.drawable.cat_4,childItem4))
    }
}