package com.mistercoding.recyclerview

data class ParentItem(
    val title:String,
    val img : Int,
    val ChildItemList : ArrayList<ChildItem>,
    var isExpandable : Boolean =  false
)
