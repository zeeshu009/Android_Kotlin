package com.mistercoding.recyclerview

data class ChildItem(val title:String,val img:Int)
