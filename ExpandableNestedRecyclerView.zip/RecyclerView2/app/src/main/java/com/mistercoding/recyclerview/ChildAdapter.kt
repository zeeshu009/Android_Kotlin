package com.mistercoding.recyclerview

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class ChildAdapter(private val Childlist : List<ChildItem>)
    :RecyclerView.Adapter<ChildAdapter.ChildRecyclerViewHolder>(){

    inner class ChildRecyclerViewHolder(itemView: View):RecyclerView.ViewHolder(itemView){
        val title : TextView = itemView.findViewById(R.id.childTextView)
        val img :ImageView = itemView.findViewById(R.id.chidlImageView)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ChildRecyclerViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item,parent,false)
        return  ChildRecyclerViewHolder(view)
    }

    override fun getItemCount(): Int {
        return Childlist.size;
    }

    override fun onBindViewHolder(holder: ChildRecyclerViewHolder, position: Int) {
        val childItem = Childlist[position]
        holder.title.text = childItem.title
        holder.img.setImageResource(childItem.img)
    }
}